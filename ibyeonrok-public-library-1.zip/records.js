/* 관리자 전용 작품 목록
   새 작품은 아래 배열 안에 객체를 복사해 추가하세요.
   category는 "캐릭터", "플롯", "세계관" 중 하나를 사용하세요. */
window.ARCHIVE_RECORDS = [
  {
    id: "character-hansol",
    category: "캐릭터",
    number: "001",
    title: "강한솔",
    subtitle: "표독한 소꿉친구와 한집살이",
    kicker: "CHILDHOOD FRIEND / CHARACTER FILE",
    description: "날 선 말투와 복잡한 속마음을 가진 소꿉친구. 가까워서 더 어려운 관계.",
    sections: [
      { heading: "기본 정보", text: "이름: 강한솔\n관계: {{user}}의 소꿉친구\n기록 유형: 캐릭터 프로필" },
      { heading: "인물 기록", text: "말은 퉁명스럽고 행동은 솔직하지 못하다. 오래 알고 지낸 사이인 만큼 사소한 습관까지 알고 있지만, 정작 자신의 감정을 표현하는 일에는 서툴다." },
      { heading: "이야기의 핵심", text: "한집살이라는 새로운 상황 속에서 익숙했던 관계가 조금씩 달라지기 시작한다." }
    ],
    tags: ["소꿉친구", "동거", "현대물"]
  },
  {
    id: "plot-campus",
    category: "플롯",
    number: "002",
    title: "낯선 조별 과제",
    subtitle: "한서윤 · 대학 캠퍼스 연애",
    kicker: "CAMPUS / PLOT FILE",
    description: "교양 수업 조별 과제에서 처음 만난 두 사람이 현실적인 대학 생활 속에서 가까워진다.",
    sections: [
      { heading: "시작", text: "교양 수업의 조별 과제. 서로 이름만 알고 있던 두 사람은 같은 팀이 되어 처음으로 긴 대화를 나눈다." },
      { heading: "전개", text: "과제 자료를 찾고 발표를 준비하면서 연락할 이유가 늘어난다. 작은 배려와 어색한 침묵이 쌓이며 관계가 변한다." },
      { heading: "분위기", text: "과장된 운명보다 일상적인 우연, 시험 기간과 약속, 답장이 늦어진 밤처럼 대학생다운 순간에 집중한다." }
    ],
    tags: ["대학교", "캠퍼스", "현실 연애"]
  },
  {
    id: "world-ibyeon",
    category: "세계관",
    number: "003",
    title: "이변록",
    subtitle: "기록되지 않은 것들을 위한 보관소",
    kicker: "ARCHIVE / WORLD FILE",
    description: "완성된 이야기와 미완의 설정, 인물의 흔적을 보관하는 도서관의 기본 기록.",
    sections: [
      { heading: "기록의 목적", text: "이곳은 창작물과 그 안에 존재하는 인물, 장소, 사건을 한데 모아 두는 공개 열람 공간이다." },
      { heading: "열람 원칙", text: "방문자는 누구나 공개된 기록을 읽을 수 있다. 새로운 기록의 등록과 수정은 관리자만 담당한다." },
      { heading: "기록의 형태", text: "캐릭터 파일, 플롯 파일, 세계관 파일을 중심으로 분류하며 각 기록은 검색과 분류 기능으로 찾아볼 수 있다." }
    ],
    tags: ["도서관", "아카이브", "창작"]
  }
];
