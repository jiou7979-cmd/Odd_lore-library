(() => {
  const records = Array.isArray(window.ARCHIVE_RECORDS) ? window.ARCHIVE_RECORDS : [];
  const entrance = document.getElementById("entrance");
  const library = document.getElementById("library");
  const enterButton = document.getElementById("enter-button");
  const grid = document.getElementById("record-grid");
  const searchInput = document.getElementById("search-input");
  const filters = document.getElementById("filters");
  const emptyState = document.getElementById("empty-state");
  const resultLabel = document.getElementById("result-label");
  const totalCount = document.getElementById("total-count");
  const modal = document.getElementById("record-modal");
  const aboutModal = document.getElementById("about-modal");
  const audio = document.getElementById("background-music");
  const musicToggle = document.getElementById("music-toggle");
  let activeFilter = "전체";
  let lastFocused = null;

  const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[ch]));

  function cardMarkup(record, index) {
    return `<button class="record-card" type="button" data-record-id="${escapeHTML(record.id)}" style="animation-delay:${Math.min(index, 8) * 55}ms">
      <span class="card-meta"><span class="category-label">${escapeHTML(record.category)}</span><span class="file-number">FILE No. ${escapeHTML(record.number)}</span></span>
      <h3 class="card-title">${escapeHTML(record.title)}</h3>
      <p class="card-subtitle">${escapeHTML(record.subtitle)}</p>
      <p class="card-description">${escapeHTML(record.description)}</p>
      <span class="card-bottom"><span>기록 상세 열람</span><span class="card-arrow">↗</span></span>
    </button>`;
  }

  function render() {
    const query = searchInput.value.trim().toLocaleLowerCase("ko");
    const filtered = records.filter(record => {
      const matchesCategory = activeFilter === "전체" || record.category === activeFilter;
      const haystack = [record.title, record.subtitle, record.description, record.category, ...(record.tags || []),
        ...(record.sections || []).flatMap(section => [section.heading, section.text])].join(" ").toLocaleLowerCase("ko");
      return matchesCategory && haystack.includes(query);
    });
    grid.innerHTML = filtered.map(cardMarkup).join("");
    emptyState.classList.toggle("hidden", filtered.length !== 0);
    resultLabel.textContent = `검색 결과 ${String(filtered.length).padStart(2, "0")}건`;
    totalCount.textContent = String(records.length).padStart(2, "0");
  }

  function openRecord(record) {
    if (!record) return;
    lastFocused = document.activeElement;
    document.getElementById("modal-category").textContent = `${record.category} FILE`;
    document.getElementById("modal-number").textContent = `FILE No. ${record.number}`;
    document.getElementById("modal-kicker").textContent = record.kicker || "ARCHIVE RECORD";
    document.getElementById("modal-title").textContent = record.title;
    document.getElementById("modal-subtitle").textContent = record.subtitle || "";
    const body = document.getElementById("modal-body");
    body.innerHTML = (record.sections || []).map(section =>
      `<section><h3>${escapeHTML(section.heading)}</h3><p>${escapeHTML(section.text)}</p></section>`
    ).join("");
    document.getElementById("modal-tags").innerHTML = (record.tags || []).map(tag => `<span>#${escapeHTML(tag)}</span>`).join("");
    modal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    document.getElementById("modal-close").focus();
  }

  function closeModal(target) {
    target.classList.add("hidden");
    if (modal.classList.contains("hidden") && aboutModal.classList.contains("hidden")) document.body.style.overflow = "";
    if (lastFocused && typeof lastFocused.focus === "function") lastFocused.focus();
  }

  enterButton.addEventListener("click", async () => {
    entrance.classList.add("hidden");
    library.classList.remove("hidden");
    window.scrollTo({top: 0, behavior: "smooth"});
    try {
      audio.volume = 0.28;
      await audio.play();
      musicToggle.classList.add("is-playing");
      musicToggle.setAttribute("aria-label", "배경 음악 끄기");
    } catch (_) {
      // 모바일 브라우저 정책 또는 MP3 파일 부재 시 사이트 이용은 계속 가능
    }
  });

  document.getElementById("home-link").addEventListener("click", event => {
    event.preventDefault();
    library.classList.add("hidden");
    entrance.classList.remove("hidden");
    window.scrollTo({top: 0, behavior: "smooth"});
  });

  musicToggle.addEventListener("click", async () => {
    if (audio.paused) {
      try {
        await audio.play();
        musicToggle.classList.add("is-playing");
        musicToggle.setAttribute("aria-label", "배경 음악 끄기");
      } catch (_) {
        alert("음악 파일 archive-theme.mp3가 업로드되어 있는지 확인해 주세요.");
      }
    } else {
      audio.pause();
      musicToggle.classList.remove("is-playing");
      musicToggle.setAttribute("aria-label", "배경 음악 켜기");
    }
  });

  grid.addEventListener("click", event => {
    const card = event.target.closest("[data-record-id]");
    if (card) openRecord(records.find(record => record.id === card.dataset.recordId));
  });
  searchInput.addEventListener("input", render);
  filters.addEventListener("click", event => {
    const button = event.target.closest("[data-filter]");
    if (!button) return;
    activeFilter = button.dataset.filter;
    filters.querySelectorAll(".filter").forEach(item => item.classList.toggle("active", item === button));
    render();
  });

  document.getElementById("modal-close").addEventListener("click", () => closeModal(modal));
  document.getElementById("about-button").addEventListener("click", () => {
    lastFocused = document.activeElement;
    aboutModal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    document.getElementById("about-close").focus();
  });
  document.getElementById("about-close").addEventListener("click", () => closeModal(aboutModal));
  [modal, aboutModal].forEach(target => target.addEventListener("click", event => {
    if (event.target === target) closeModal(target);
  }));
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      if (!modal.classList.contains("hidden")) closeModal(modal);
      if (!aboutModal.classList.contains("hidden")) closeModal(aboutModal);
    }
  });
  render();
})();